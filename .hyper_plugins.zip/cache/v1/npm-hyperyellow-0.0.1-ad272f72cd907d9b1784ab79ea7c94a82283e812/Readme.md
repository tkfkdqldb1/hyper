# spongebob

Turns [hyperterm](https://hyperterm.org) yellow.

## How to use

Add `spongebob` to `plugins` in `~/.hyperterm.js`.
